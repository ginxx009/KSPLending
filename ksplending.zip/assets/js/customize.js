$(document).ready(function() {
    $("#loantype").find('select').change(function() {
        var $val = $(this).val();

        if($val === 'Personal'){
            $('.loan_amount_personal').show();
            $('.loan_amount_business').hide();
        }else if($val === 'Business'){
            $('.loan_amount_personal').hide();
            $('.loan_amount_business').show();
        }else{
            $('.loan_amount_personal').hide();
            $('.loan_amount_business').hide();
        }
    });
});

$( function() {
    $( "#datepicker" ).datepicker();
  } );

$(document).ready( function() {
    $('#hideMe').delay(5000).fadeOut();
});
