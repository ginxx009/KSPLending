-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 08, 2019 at 01:01 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'primary key',
  `loan` varchar(255) NOT NULL COMMENT 'employee name',
  `loan_type` varchar(255) NOT NULL COMMENT 'employee salary',
  `loan_amount` int(11) NOT NULL COMMENT 'employee age',
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `civilstatus` varchar(255) NOT NULL,
  `birthday` varchar(255) NOT NULL,
  `age` int(50) NOT NULL,
  `dependents` int(50) NOT NULL,
  `spousefirstname` varchar(255) NOT NULL,
  `spouselastname` varchar(255) NOT NULL,
  `spousemiddlename` varchar(255) NOT NULL,
  `spouseage` int(50) NOT NULL,
  `spousebirthday` varchar(255) NOT NULL,
  `homeaddress` varchar(255) NOT NULL,
  `zipcode` int(50) NOT NULL,
  `lengthofstay` int(50) NOT NULL,
  `hometype` varchar(255) NOT NULL,
  `emailaddress` varchar(255) NOT NULL,
  `homephonenumber` int(50) NOT NULL,
  `businessphonenumber` int(50) NOT NULL,
  `mobilenumber` int(50) NOT NULL,
  `nameofbusiness` varchar(255) NOT NULL,
  `natureofbusiness` varchar(255) NOT NULL,
  `addressofbusiness` varchar(255) NOT NULL,
  `yearsofbusiness` int(50) NOT NULL,
  `nameofcomaker` varchar(255) NOT NULL,
  `addressofcomaker` varchar(255) NOT NULL,
  `numberofcomaker` int(50) NOT NULL,
  `balance` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=180 DEFAULT CHARSET=latin1 COMMENT='datatable demo table';

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `loan`, `loan_type`, `loan_amount`, `firstname`, `lastname`, `middlename`, `gender`, `civilstatus`, `birthday`, `age`, `dependents`, `spousefirstname`, `spouselastname`, `spousemiddlename`, `spouseage`, `spousebirthday`, `homeaddress`, `zipcode`, `lengthofstay`, `hometype`, `emailaddress`, `homephonenumber`, `businessphonenumber`, `mobilenumber`, `nameofbusiness`, `natureofbusiness`, `addressofbusiness`, `yearsofbusiness`, `nameofcomaker`, `addressofcomaker`, `numberofcomaker`, `balance`) VALUES
(169, 'First Loan Application', 'Business', 10000, 'test', 'test', 'test', '', '', '', 0, 0, '', '', '', 0, '', '', 0, 0, '', '', 0, 0, 0, '', '', '', 0, '', '', 0, 20000),
(170, 'First Loan Application', 'Business', 15000, '', '', '', '', '', '', 0, 0, '', '', '', 0, '', '', 0, 0, '', '', 0, 0, 0, '', '', '', 0, '', '', 0, 5000),
(171, 'First Loan Application', 'Business', 15000, 'test3', 'test3', 'test3', 'Male', 'Single', '', 0, 0, '', '', '', 0, '', '', 0, 0, '', '', 0, 0, 0, '', '', '', 0, '', '', 0, 5000),
(172, 'First Loan Application', 'Personal', 0, 'test4', 'test4', 'test4', 'Male', 'Single', '09/09/2019', 21, 2, 'test4', 'test4', 'test4', 21, '09/08/2019', '119 P5 Bagong Tanyag Taguig City', 6300, 2, 'Owned', 'Test@test.com', 123123, 123123123, 123123123, 'test4', 'test4', '119 P5 Bagong Tanyag Taguig City', 2, 'test4', '119 P5 Bagong Tanyag Taguig City', 123123123, 0),
(173, 'First Loan Application', 'Personal', 0, 'test5', 'test5', 'test5', 'Male', 'Single', '09/22/2019', 21, 2, 'test5', 'test5', 'test5', 21, '09/15/2019', '119 P5 Bagong Tanyag Taguig City', 6300, 2, 'Owned', 'Test@test.com', 123123, 123123123, 123123123, 'test5', 'test5', '119 P5 Bagong Tanyag Taguig City', 2, 'test5', '119 P5 Bagong Tanyag Taguig City', 123123123, 0),
(174, 'First Loan Application', 'Personal', 0, 'test6', 'test6', 'test6', 'Male', 'Single', '09/12/2019', 21, 2, 'test6', 'test6', 'test6', 21, '08/25/2019', '119 P5 Bagong Tanyag Taguig City', 6300, 2, 'Owned', 'Test@test.com', 123123, 123123132, 123123123, 'test6', 'test6', '119 P5 Bagong Tanyag Taguig City', 2, 'test6', '119 P5 Bagong Tanyag Taguig City', 123123123, 0),
(175, 'First Loan Application', 'Personal', -5000, 'test7', 'test7', 'test7', '', '', '', 0, 0, '', '', '', 0, '', '', 0, 0, '', '', 0, 0, 0, '', '', '', 0, '', '', 0, 5000),
(176, 'First Loan Application', 'Business', -1000, 'test8', 'test8', 'test8', '', '', '', 0, 0, '', '', '', 0, '', '', 0, 0, '', '', 0, 0, 0, '', '', '', 0, '', '', 0, 1000),
(177, 'First Loan Application', 'Personal', 2000, 'test9', 'test9', 'test9', '', '', '', 0, 0, '', '', '', 0, '', '', 0, 0, '', '', 0, 0, 0, '', '', '', 0, '', '', 0, 500),
(178, 'First Loan Application', 'Business', 50000, 'test15', 'test15', 'test15', 'Male', 'Single', '11/08/2019', 15, 1, 'test15', 'test15', 'test15', 21, '11/07/2019', '119 P5 Bagong Tanyag Taguig City', 6300, 2, 'Owned', 'test15@test.com', 123123123, 123123123, 123123123, 'test15', 'test15', '119 P5 Bagong Tanyag Taguig City', 2, 'test15', 'test15', 123123123, 0),
(179, 'First Loan Application', 'Personal', 15000, 'test19', 'test19', 'test19', 'Male', 'Single', '09/29/2019', 2, 2, 'test19', 'test19', 'test19', 2, '09/30/2019', '119 P5 Bagong Tanyag Taguig City', 6300, 2, 'Owned', 'test19@test.com', 123123123, 12312312, 123123123, 'test19', 'test19', '119 P5 Bagong Tanyag Taguig City', 2, 'test19', 'test19', 1123123, 0);

-- --------------------------------------------------------

--
-- Table structure for table `investor`
--

DROP TABLE IF EXISTS `investor`;
CREATE TABLE IF NOT EXISTS `investor` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `investment_amount` int(50) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `civilstatus` varchar(255) NOT NULL,
  `birthday` varchar(255) NOT NULL,
  `age` int(50) NOT NULL,
  `dependents` int(50) NOT NULL,
  `spousefirstname` varchar(255) NOT NULL,
  `spouselastname` varchar(255) NOT NULL,
  `spousemiddlename` varchar(255) NOT NULL,
  `spouseage` int(50) NOT NULL,
  `spousebirthday` varchar(255) NOT NULL,
  `homeaddress` varchar(255) NOT NULL,
  `zipcode` int(50) NOT NULL,
  `lengthofstay` int(50) NOT NULL,
  `hometype` varchar(255) NOT NULL,
  `emailaddress` varchar(255) NOT NULL,
  `homephonenumber` int(50) NOT NULL,
  `businessphonenumber` int(50) NOT NULL,
  `mobilenumber` int(50) NOT NULL,
  `nameofbusiness` varchar(255) NOT NULL,
  `natureofbusiness` varchar(255) NOT NULL,
  `addressofbusiness` varchar(255) NOT NULL,
  `yearsofbusiness` int(50) NOT NULL,
  `referal_code` varchar(255) NOT NULL,
  `referral_link` varchar(255) NOT NULL,
  `bonus` double NOT NULL,
  `package` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `investor`
--

INSERT INTO `investor` (`id`, `investment_amount`, `firstname`, `lastname`, `middlename`, `gender`, `civilstatus`, `birthday`, `age`, `dependents`, `spousefirstname`, `spouselastname`, `spousemiddlename`, `spouseage`, `spousebirthday`, `homeaddress`, `zipcode`, `lengthofstay`, `hometype`, `emailaddress`, `homephonenumber`, `businessphonenumber`, `mobilenumber`, `nameofbusiness`, `natureofbusiness`, `addressofbusiness`, `yearsofbusiness`, `referal_code`, `referral_link`, `bonus`, `package`) VALUES
(1, 49000, 'test1', 'test1', 'test1', 'Male', 'Single', '09/29/2019', 21, 2, 'test1', 'test1', 'test1', 21, '09/29/2019', '119 P5 Bagong Tanyag Taguig City', 6300, 2, 'Owned', 'Test@test.com', 123123, 123123123, 123123123, 'test1', 'test1', '119 P5 Bagong Tanyag Taguig City', 2, 'f2V617HWsC', '', 4579.98, 2),
(2, 48000, 'test2', 'test2', 'test2', 'Male', 'Single', '09/29/2019', 21, 2, 'test2', 'test2', 'test2', 21, '09/29/2019', '119 P5 Bagong Tanyag Taguig City', 6300, 2, 'Owned', 'Test@test.com', 123123123, 123123123, 123123123, 'test2', 'test2', '119 P5 Bagong Tanyag Taguig City', 2, 'fARsTEg6n4', 'f2V617HWsC', 3779.98, 1),
(3, 48000, 'test3', 'test3', 'test3', 'Male', 'Single', '09/29/2019', 21, 2, 'test3', 'test3', 'test3', 21, '09/29/2019', '119 P5 Bagong Tanyag Taguig City', 6300, 2, 'Owned', 'Test@test.com', 123123, 123123, 123123, 'test3', 'test3', '119 P5 Bagong Tanyag Taguig City', 2, 'YTEo7lLDav', 'fARsTEg6n4', 3459.94, 1),
(4, 49999, 'test4', 'test4', 'test4', 'Male', 'Single', '09/29/2019', 21, 2, 'test4', 'test4', 'test4', 21, '09/29/2019', '119 P5 Bagong Tanyag Taguig City', 6300, 2, 'Owned', '', 123123, 123123, 123123, 'test4', 'test4', '119 P5 Bagong Tanyag Taguig City', 2, 'fNuODsB4yF', 'YTEo7lLDav', 3159.95, 1),
(5, 49999, 'test5', 'test5', 'test5', 'Male', 'Married', '10/06/2019', 21, 2, 'test5', 'test5', 'test5', 21, '09/29/2019', '119 P5 Bagong Tanyag Taguig City', 6300, 2, 'Owned', 'Test@test.com', 123123, 123123, 123123, 'test5', 'test5', '119 P5 Bagong Tanyag Taguig City', 2, 'MGj6218FY6', 'fNuODsB4yF', 2060, 1),
(6, 30000, 'test6', 'test6', 'test6', 'Male', 'Single', '09/29/2019', 21, 2, 'test6', 'test6', 'test6', 2, '08/25/2019', '119 P5 Bagong Tanyag Taguig City', 6300, 2, 'Owned', 'Test@test.com', 123123123, 123123123, 123123123, 'test6', 'test6', '119 P5 Bagong Tanyag Taguig City', 2, 'jgCHz0cPff', 'MGj6218FY6', 880, 1),
(7, 8000, 'test7', 'test7', 'test7', 'Male', 'Single', '09/29/2019', 21, 2, 'test7', 'test7', 'test7', 21, '09/29/2019', '119 P5 Bagong Tanyag Taguig City', 6300, 2, 'Owned', 'Test@test.com', 123123, 123123123, 123123, 'test7', 'test7', '119 P5 Bagong Tanyag Taguig City', 2, '7T84Ku53lW', 'jgCHz0cPff', 800, 1),
(8, 8000, 'test8', 'test8', 'test8', 'Male', 'Single', '09/29/2019', 21, 2, 'test8', 'test8', 'test8', 21, '09/30/2019', '119 P5 Bagong Tanyag Taguig City', 6300, 2, 'Owned', 'Test@test.com', 123123, 123123123, 123123123, 'test8', 'test8', '119 P5 Bagong Tanyag Taguig City', 2, 'UQC9YJhSIl', '7T84Ku53lW', 1200, 1),
(9, 20000, 'test9', 'test9', 'test9', 'Male', 'Single', '09/29/2019', 21, 2, 'test9', 'test9', 'test9', 21, '09/30/2019', '119 P5 Bagong Tanyag Taguig City', 6300, 2, 'Owned', 'Test@test.com', 123123, 123123, 123123, 'test9', 'test9', '119 P5 Bagong Tanyag Taguig City', 2, 'pyyuCo4fNT', 'UQC9YJhSIl', 1000, 1),
(10, 20000, 'testaccount1', 'testaccount1', 'testaccount1', 'Female', 'Single', '09/29/2019', 21, 2, 'testaccount1', 'testaccount1', 'testaccount1', 21, '09/29/2019', '119 P5 Bagong Tanyag Taguig City', 6300, 2, 'Owned', 'Test@test.com', 123123, 123123, 123123, 'testaccount1', 'testaccount1', '119 P5 Bagong Tanyag Taguig City', 2, 'V5Cz6Bda2Z', 'pyyuCo4fNT', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
CREATE TABLE IF NOT EXISTS `logs` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `date` timestamp NOT NULL,
  `action` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `date`, `action`) VALUES
(1, '2019-09-18 04:21:27', 'Inserted 5000 successfully'),
(2, '2019-09-18 04:26:15', 'Update data successfully'),
(3, '2019-09-18 04:56:05', 'Inserted data successfully'),
(4, '2019-09-18 05:28:49', 'Inserted data successfully'),
(5, '2019-09-18 05:30:21', 'Inserted data successfully'),
(6, '2019-09-18 05:32:29', 'Inserted data successfully'),
(7, '2019-09-18 05:33:14', 'Inserted data successfully'),
(8, '2019-09-18 05:35:01', 'Inserted 5000 successfully'),
(9, '2019-09-18 05:35:15', 'Inserted 1000 successfully'),
(10, '2019-09-18 05:37:12', 'Inserted data successfully'),
(11, '2019-09-18 05:37:30', 'Inserted 10000 successfully'),
(12, '2019-09-18 06:40:13', 'Inserted 5000 successfully'),
(13, '2019-09-18 06:41:09', 'Inserted 5000 successfully'),
(14, '2019-09-18 06:42:38', 'Inserted 5000 successfully'),
(15, '2019-09-18 06:43:03', 'Inserted 2500 successfully'),
(16, '2019-10-02 18:52:28', 'Inserted 500 successfully'),
(17, '2019-10-02 22:41:34', 'Inserted data successfully'),
(18, '2019-10-03 00:38:48', 'successfully deleted an investors account'),
(19, '2019-10-03 01:35:31', 'Inserted data successfully');

-- --------------------------------------------------------

--
-- Table structure for table `total_cash`
--

DROP TABLE IF EXISTS `total_cash`;
CREATE TABLE IF NOT EXISTS `total_cash` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `total_cash_amount` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `total_cash`
--

INSERT INTO `total_cash` (`id`, `total_cash_amount`) VALUES
(1, 5000),
(2, 2500),
(3, 500);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `type` int(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `type`) VALUES
(1, 'admin', '$2y$10$vKgkboG7PPrpb4Dq6JRjXOY3/kIPEpW62mYaMRIYIZkeZtOp24gUi', 1),
(2, 'cashier', '$2y$10$Ifb6cZm5KHn7p0hCb2PFueKyUww0jNMYS36sD2f9PspcqeW/2urb2', 2);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
